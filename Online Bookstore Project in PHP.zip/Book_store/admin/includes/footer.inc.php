<div id="footer-wrap">
	<p id="legal">(c) 2010 OurSite. Design by <a href="https://www.globalwebsolution.biz">Global Web Solution</a>.</p>
	</div>